import React from 'react';

const App = () => <h1>Hello React!!!</h1>

export default App;